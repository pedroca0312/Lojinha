<?php


    //configs de acesso ao banco
    const HOST = "localhost";
    const BANCO = "bd_lojinhaPedrinDaniel";
    const USUARIO = "root";
    const SENHA = "root";